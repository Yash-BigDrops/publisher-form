import CreativeForm from "@/app/Form/CreativeForm";

export default function Home() {
  return (
   <main>
    <CreativeForm />
   </main>
  );
}

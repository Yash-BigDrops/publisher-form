// Export all constants
export * from './fileUpload'

// Telegram Bot Configuration
export const TELEGRAM_BOT_URL = 'https://t.me/BigDropsMarketingBot?start=from_web_form'
